
const i18nNodes = document.querySelectorAll('[data-i18n]');
const langToggle = document.getElementById('langToggle');

// Guardamos el español original del HTML para poder regresar a él
const ES = {};
i18nNodes.forEach(el => { ES[el.dataset.i18n] = el.innerHTML.trim(); });

let currentLang = 'es';

function setLang(lang) {
  currentLang = lang;
  const dict = lang === 'en' ? EN : ES;

  i18nNodes.forEach(el => {
    const text = dict[el.dataset.i18n];
    if (text) el.innerHTML = text;
  });

  document.documentElement.lang = lang;
  document.title = META[lang].title;
  langToggle.textContent = META[lang].langBtn;
  langToggle.setAttribute('aria-label', META[lang].langLabel);
  updateMenuLabel();

  try { localStorage.setItem('lang', lang); } catch (e) { /* modo privado */ }
}

langToggle.addEventListener('click', () => setLang(currentLang === 'es' ? 'en' : 'es'));

// Prioridad: ?lang=en en la URL (útil para Upwork) > elección guardada > español
const urlLang = new URLSearchParams(location.search).get('lang');
let savedLang = null;
try { savedLang = localStorage.getItem('lang'); } catch (e) {}
const initialLang = urlLang || savedLang;
if (initialLang === 'en') setLang('en');

/* ---------- 2. MENÚ MÓVIL ---------- */
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');

function updateMenuLabel() {
  const open = menuToggle.getAttribute('aria-expanded') === 'true';
  menuToggle.setAttribute('aria-label', open ? META[currentLang].menuClose : META[currentLang].menuOpen);
}

function toggleMenu(force) {
  const open = typeof force === 'boolean' ? force : menuToggle.getAttribute('aria-expanded') !== 'true';
  menuToggle.setAttribute('aria-expanded', open);
  nav.classList.toggle('is-open', open);
  updateMenuLabel();
}

menuToggle.addEventListener('click', () => toggleMenu());
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => toggleMenu(false)));
document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMenu(false); });

/* ---------- 3. HEADER + LINK ACTIVO ---------- */
const header = document.getElementById('header');
const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

const navLinks = [...document.querySelectorAll('.nav__list a')];
const sections = navLinks.map(a => document.querySelector(a.getAttribute('href')));

const sectionObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    navLinks.forEach(a => {
      const active = a.getAttribute('href') === '#' + entry.target.id;
      a.classList.toggle('is-active', active);
      if (active) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
    });
  });
}, { rootMargin: '-45% 0px -50% 0px' });

sections.forEach(s => s && sectionObserver.observe(s));

/* ---------- 4. APARICIÓN AL HACER SCROLL ---------- */
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target); // solo una vez
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

// Pequeño escalonado entre elementos hermanos (tarjetas, pasos)
document.querySelectorAll('.reveal').forEach(el => {
  const siblings = [...el.parentElement.children].filter(c => c.classList.contains('reveal'));
  const index = siblings.indexOf(el);
  el.style.transitionDelay = `${Math.min(index, 4) * 80}ms`;
  revealObserver.observe(el);
});

/* ---------- 5. TIRA DE TECNOLOGÍAS ---------- */
// Duplicamos la lista para que el loop sea continuo (la copia se oculta a lectores de pantalla)
const track = document.querySelector('.stack-strip__track');
if (track) {
  [...track.children].forEach(li => {
    const clone = li.cloneNode(true);
    clone.setAttribute('aria-hidden', 'true');
    track.appendChild(clone);
  });
}

/* Año del footer */
document.getElementById('year').textContent = new Date().getFullYear();
