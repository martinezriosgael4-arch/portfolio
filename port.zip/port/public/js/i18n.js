
const EN = {
  "skip": "Skip to content",

  "nav.projects": "Projects",
  "nav.services": "Services",
  "nav.process": "Process",
  "nav.about": "About",
  "nav.contact": "Contact",

  "hero.status": "Available for projects · Guadalajara, MX (UTC−6)",
  "hero.title": "I build web systems that bring order to how your business runs.",
  "hero.text": "I'm Gael, a full-stack developer. I design and build internal tools, admin panels, CRMs and WhatsApp integrations with <strong>Laravel, PHP, MySQL and Next.js</strong>, from discovery to deployment.",
  "hero.cta1": "View projects",
  "hero.cta2": "Download CV",

  "projects.eyebrow": "01 · Projects",
  "projects.title": "Real systems for real businesses",
  "projects.lead": "A selection of internal systems and websites I've built. Company projects are shown with sample data for confidentiality.",

  "p1.tag": "Business system",
  "p1.status": "Internal use",
  "p1.title": "Multi-department ticketing and workflow system",
  "p1.desc": "Internal platform that centralizes requests between departments (administration, operations and sales) with owners, statuses and tracking.",
  "p1.b1": "Status workflow with escalation and 3 ticket types, each with its own validation rules",
  "p1.b2": "Role-based dashboards with Chart.js: each user sees only their area",
  "p1.b3": "Merchandise returns and invoice cancellations with generated PDFs",
  "p1.b4": "Automatic WhatsApp alerts when a ticket goes unattended",

  "p2.tag": "B2B portal",
  "p2.status": "In development",
  "p2.title": "Operations portal for clients and sales teams",
  "p2.desc": "Information hub where admins, sales reps and clients check orders, products and shipments, each one seeing only what they're allowed to.",
  "p2.b1": "Role-based access control enforced in the backend, not just the UI",
  "p2.b2": "Excel import with preview and confirmation before saving",
  "p2.b3": "Versioned REST API with token authentication and an audit log",
  "p2.b4": "Responsive interface built for desktop and mobile",

  "p3.tag": "Client website",
  "p3.status": "Live",
  "p3.desc": "Website for a mattress store, with a quote flow that sends customers straight to WhatsApp with the size and model they picked.",
  "p3.b1": "Dynamic size-based quote tool connected to WhatsApp",
  "p3.b2": "Built without frameworks: PHP, MySQL and vanilla JavaScript",
  "p3.b3": "Deployed on Hostinger; cleaned up the search index after a spam attack",
  "p3.link": "Visit live site",

  "more.title": "More projects",
  "more.wip": "In development",
  "more.personal": "Personal project",
  "more.code": "View code",
  "m1.title": "Sales CRM",
  "m1.desc": "For a lighting company: monthly targets, sales pipeline, activities with manager feedback and visit-frequency alerts per client.",
  "m2.title": "Team task manager",
  "m2.desc": "Kanban board with drag & drop, calendar view, team roles and automatic WhatsApp reminders.",
  "m3.title": "WhatsApp bot platform",
  "m3.desc": "Multi-tenant SaaS that lets businesses answer messages, take bookings and review conversations in one dashboard.",

  "services.eyebrow": "02 · Services",
  "services.title": "How I can help",
  "s1.title": "Internal systems and admin panels",
  "s1.desc": "Roles and permissions, approval workflows, PDF/Excel reports and dashboards. So your processes stop living in spreadsheets.",
  "s2.title": "WhatsApp integrations and automation",
  "s2.desc": "Notifications, reminders and bots connected to your system through APIs, so information reaches the right person on its own.",
  "s3.title": "CRMs and sales tools",
  "s3.desc": "Client tracking, sales targets and team activity, with different views for reps, managers and leadership.",
  "s4.title": "Websites and landing pages",
  "s4.desc": "Fast, SEO-friendly sites with forms and quote tools that turn visits into leads.",

  "process.eyebrow": "03 · Process",
  "process.title": "How I work",
  "process.lead": "Short, visible deliveries. You know what's being built every week.",
  "st1.title": "Discovery",
  "st1.desc": "I learn how the process works today, who uses it and where time gets lost.",
  "st2.title": "Proposal and MVP",
  "st2.desc": "I define scope, data structure and a first working version with the essentials.",
  "st3.title": "Iterative development",
  "st3.desc": "Weekly reviewable progress, adjusted to real usage.",
  "st4.title": "Deployment and support",
  "st4.desc": "Launch on a server or hosting, a short training session and follow-up after delivery.",

  "about.eyebrow": "04 · About",
  "about.title": "Development with a business focus",
  "about.p1": "I work as an internal tools developer at a company in Guadalajara, building systems that several departments use every day. On the side, I work with freelance clients.",
  "about.p2": "I like to understand the process before writing code: what repeats, what gets lost and what can be automated.",
  "about.exp": "Experience",
  "about.e1": "Internal Systems Developer",
  "about.e1s": "Company in Guadalajara · 20XX – Present",
  "about.e2": "Freelance Developer",
  "about.e2s": "Websites, systems and automation · 20XX – Present",
  "about.e3": "Computer Engineering",
  "about.e3s": "Universidad de guadalajara · In progress",
  "about.stack": "Stack",
  "about.db": "Data",
  "about.infra": "Infra",
  "about.integrations": "Integrations",
  "about.facts": "Quick facts",
  "about.loc": "Location",
  "about.tz": "Time zone",
  "about.mode": "Work mode",
  "about.modev": "Remote / freelance",
  "about.es": "Spanish",
  "about.en": "English",
  "about.native": "Native",
  "about.b2": "B2 certified",

  "contact.eyebrow": "05 · Contact",
  "contact.title": "Is one of your processes still living in Excel, email or WhatsApp?",
  "contact.text": "Tell me how it works and I'll tell you how I'd turn it into a system. I reply within 24 hours.",

  "footer.top": "Back to top ↑"
};

/* Textos fuera de data-i18n (atributos, título de la pestaña) */
const META = {
  es: {
    title: document.title,
    langBtn: "EN", langLabel: "Switch to English",
    menuOpen: "Abrir menú", menuClose: "Cerrar menú"
  },
  en: {
    title: "Gael Martinez — Full-Stack Laravel Developer | Web systems for businesses",
    langBtn: "ES", langLabel: "Cambiar a español",
    menuOpen: "Open menu", menuClose: "Close menu"
  }
};
